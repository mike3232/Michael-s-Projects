# cc0week1clockproject
Practicing HTML/CSS/JS with a clock project
